

#ifdef MODELS_H
#define MODELS_H


void create_model( char * model_name );//Method that creates a model
void create_model_table( char * model_name );//Method that creates a model table on the database
void create_model_procedures( char * model_name );//Method that creates the model procedures

#endif
